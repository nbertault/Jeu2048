/* 
 * File:   Plateau.cpp
 * Author: nbertault
 * 
 * Created on 31 janvier 2024, 08:54
 */

#include "plateau.h"

Plateau::Plateau()
{
    score = 0;
    nbCoups = 0;
}

void Plateau::Afficher()
{
    int laGrille[TAILLE][TAILLE];
    int indice;

    system("clear");
    leJeu.ObtenirGrille(laGrille);
    cout << "| Score : " << score << " | Nombre de coups : " << nbCoups << " |" << endl;
    cout << endl;
    for (int ligne = 0; ligne < 4; ligne++)
    {
        cout << " +";
        for (indice = 0; indice < 4; indice++)
        {
            cout << setw(7) << setfill('-') << '+';

        }
        cout << endl << " |";
        for (indice = 0; indice < 4; indice++)
        {
            if (laGrille[ligne][indice] != 0)
                cout << setfill(' ') << setw(6) << laGrille[ligne][indice] << '|'; // affichage d'une ligne de la grille
            else
            {
                cout << setfill(' ') << setw(7) << '|'; // affichage d'une ligne de la grille
            }
        }
        cout << endl;
    }
    cout << " +";
    for (indice = 0; indice < 4; indice++)// affichage de la dernière ligne du tableau
        cout << setw(7) << setfill('-') << '+';

    cout << endl << endl << "F pour sortir du jeu" << endl;
    cout << "Votre déplacement : H(↑), B(↓), G(←), D(→) : " << endl; // affichage du texte sous le tableau
}

bool Plateau::JouerCoup()
{
    bool retour = false;
    char touche;
    cin >> touche;
    touche = toupper(touche);
    if (strchr("BHGD", touche) != nullptr)
    {
        nbCoups++;
        leJeu.Deplacer(touche);
        leJeu.PlacerNouvelleTuille();
        Afficher();
    }
    if (touche == 'F')
        retour = true;
    return retour;
}

